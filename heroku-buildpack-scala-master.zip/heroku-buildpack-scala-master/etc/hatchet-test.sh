HATCHET_DEPLOY_STRATEGY=git \
HATCHET_BUILDPACK_BASE=https://github.com/heroku/heroku-buildpack-scala.git \
HATCHET_BUILDPACK_BRANCH=master \
rspec
